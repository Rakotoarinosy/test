from django.apps import AppConfig


class FrontofficeConfig(AppConfig):
    name = 'frontoffice'
